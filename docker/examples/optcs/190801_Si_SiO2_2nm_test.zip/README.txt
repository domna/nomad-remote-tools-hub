Dear Mark,

Here is a spectrum of Si wafer with 2nm SiO2.

*.SE		binary file of the vendor
*.dat		convert into an ASCI file of the vendor, from completeease in wvase
*.txt		data I converted in my own matrix format („.._mat.txt“ contains the data and „…_fehler.txt“ the corresponding uncertainties). 

Best regards
Chris 


E standard ellipsometry,
letzte beide spalten fehler von psi und delta (degree)

Software
https://www.jawoollam.com/ellipsometry-software/completeease --> Creates *.SE
wvase --> *.SE to *.dat
Sturms own tool --> *.dat to *_mat.txt and *_mat_fehler.txt
